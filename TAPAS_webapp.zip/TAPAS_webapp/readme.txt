You must create your binary from a MotorWare project in CCS.
Once built, copy from the build location
ex: 
C:\ti\motorware\motorware_1_01_00_16\sw\solutions\instaspin_foc\boards\TAPAS_V1.0\f28x\f2806xF\projects\ccs5\proj_lab02c\Release


to the webapp location:
C:\ti\guicomposer\webapps\TAPAS_webapp\

and rename
proj_lab###.out 

to
appProgram.out

then simply run
InstaSPIN_UNIVERSAL.exe
